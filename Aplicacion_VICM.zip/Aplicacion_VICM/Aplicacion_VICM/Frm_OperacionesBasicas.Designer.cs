﻿namespace Aplicacion_VICM
{
    partial class Frm_OperacionesBasicas
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_num1 = new System.Windows.Forms.TextBox();
            this.tb_num2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_suma = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_resultado = new System.Windows.Forms.Label();
            this.lb_cantidad = new System.Windows.Forms.Label();
            this.bt_resta = new System.Windows.Forms.Button();
            this.bt_multiplicacion = new System.Windows.Forms.Button();
            this.bt_division = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_num1
            // 
            this.tb_num1.Location = new System.Drawing.Point(89, 46);
            this.tb_num1.Name = "tb_num1";
            this.tb_num1.Size = new System.Drawing.Size(100, 20);
            this.tb_num1.TabIndex = 0;
            // 
            // tb_num2
            // 
            this.tb_num2.Location = new System.Drawing.Point(89, 96);
            this.tb_num2.Name = "tb_num2";
            this.tb_num2.Size = new System.Drawing.Size(100, 20);
            this.tb_num2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Número 1:";
            // 
            // bt_suma
            // 
            this.bt_suma.BackColor = System.Drawing.SystemColors.Highlight;
            this.bt_suma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_suma.ForeColor = System.Drawing.Color.White;
            this.bt_suma.Location = new System.Drawing.Point(101, 135);
            this.bt_suma.Name = "bt_suma";
            this.bt_suma.Size = new System.Drawing.Size(75, 23);
            this.bt_suma.TabIndex = 3;
            this.bt_suma.Text = "Suma";
            this.bt_suma.UseVisualStyleBackColor = false;
            this.bt_suma.Click += new System.EventHandler(this.bt_suma_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(89, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Número 2:";
            // 
            // lb_resultado
            // 
            this.lb_resultado.AutoSize = true;
            this.lb_resultado.Location = new System.Drawing.Point(89, 322);
            this.lb_resultado.Name = "lb_resultado";
            this.lb_resultado.Size = new System.Drawing.Size(58, 13);
            this.lb_resultado.TabIndex = 5;
            this.lb_resultado.Text = "Resultado:";
            // 
            // lb_cantidad
            // 
            this.lb_cantidad.AutoSize = true;
            this.lb_cantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cantidad.Location = new System.Drawing.Point(147, 322);
            this.lb_cantidad.Name = "lb_cantidad";
            this.lb_cantidad.Size = new System.Drawing.Size(0, 13);
            this.lb_cantidad.TabIndex = 6;
            // 
            // bt_resta
            // 
            this.bt_resta.BackColor = System.Drawing.Color.Red;
            this.bt_resta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_resta.ForeColor = System.Drawing.Color.White;
            this.bt_resta.Location = new System.Drawing.Point(101, 178);
            this.bt_resta.Name = "bt_resta";
            this.bt_resta.Size = new System.Drawing.Size(75, 23);
            this.bt_resta.TabIndex = 7;
            this.bt_resta.Text = "Resta";
            this.bt_resta.UseVisualStyleBackColor = false;
            this.bt_resta.Click += new System.EventHandler(this.bt_resta_Click);
            // 
            // bt_multiplicacion
            // 
            this.bt_multiplicacion.BackColor = System.Drawing.Color.Black;
            this.bt_multiplicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_multiplicacion.ForeColor = System.Drawing.Color.White;
            this.bt_multiplicacion.Location = new System.Drawing.Point(101, 220);
            this.bt_multiplicacion.Name = "bt_multiplicacion";
            this.bt_multiplicacion.Size = new System.Drawing.Size(75, 23);
            this.bt_multiplicacion.TabIndex = 8;
            this.bt_multiplicacion.Text = "Multi";
            this.bt_multiplicacion.UseVisualStyleBackColor = false;
            this.bt_multiplicacion.Click += new System.EventHandler(this.bt_multiplicacion_Click);
            // 
            // bt_division
            // 
            this.bt_division.BackColor = System.Drawing.Color.DarkOrange;
            this.bt_division.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_division.ForeColor = System.Drawing.Color.White;
            this.bt_division.Location = new System.Drawing.Point(101, 263);
            this.bt_division.Name = "bt_division";
            this.bt_division.Size = new System.Drawing.Size(75, 23);
            this.bt_division.TabIndex = 9;
            this.bt_division.Text = "Division";
            this.bt_division.UseVisualStyleBackColor = false;
            this.bt_division.Click += new System.EventHandler(this.bt_division_Click);
            // 
            // Frm_OperacionesBasicas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(284, 361);
            this.Controls.Add(this.bt_division);
            this.Controls.Add(this.bt_multiplicacion);
            this.Controls.Add(this.bt_resta);
            this.Controls.Add(this.lb_cantidad);
            this.Controls.Add(this.lb_resultado);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bt_suma);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_num2);
            this.Controls.Add(this.tb_num1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Frm_OperacionesBasicas";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "Operaciones Básicas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_num1;
        private System.Windows.Forms.TextBox tb_num2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_suma;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_resultado;
        private System.Windows.Forms.Label lb_cantidad;
        private System.Windows.Forms.Button bt_resta;
        private System.Windows.Forms.Button bt_multiplicacion;
        private System.Windows.Forms.Button bt_division;
    }
}

