﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicacion_VICM
{
    public partial class Frm_OrdernarNNumerosDescendente : Form
    {
        public Frm_OrdernarNNumerosDescendente()
        {
            InitializeComponent();
            Bitmap img = new Bitmap(Application.StartupPath + "/img/Fondo2.jpg");
            this.BackgroundImage = img;
        }

        Decimal[] num = new decimal[120];
        int contador = 0;
        private void Bt_agregar_Click(object sender, EventArgs e)
        {
            ListaNums.Items.Add(tb_num.Text);
            num[contador] = Convert.ToDecimal(tb_num.Text);
            contador++;

            tb_num.Clear();
            tb_num.Focus();
        }

        private void Bt_ordenar_Click(object sender, EventArgs e)
        {
            for (int n = 0; n <= contador - 1; n++)
            {
                for (int k = n + 1; k <= contador; k++)
                {
                    if (num[n] < num[k])
                    {
                        decimal aux = num[n];
                        num[n] = num[k];
                        num[k] = aux;
                    }
                }
            }
            for (int m = 0; m <= contador - 1; m++)
            {
                Lista_Ordenar.Items.Add(Convert.ToString(num[m]));
            }
        }

        private void Frm_OrdernarNNumerosDescendente_Load(object sender, EventArgs e)
        {

        }
    }
}
