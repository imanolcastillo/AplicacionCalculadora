﻿namespace Aplicacion_VICM
{
    partial class Frm_Promedio10Materias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_num = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_contador = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bt_agregar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_promedio = new System.Windows.Forms.TextBox();
            this.ListaCalif = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // tb_num
            // 
            this.tb_num.Location = new System.Drawing.Point(13, 29);
            this.tb_num.Name = "tb_num";
            this.tb_num.Size = new System.Drawing.Size(100, 20);
            this.tb_num.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número:";
            // 
            // tb_contador
            // 
            this.tb_contador.Location = new System.Drawing.Point(12, 113);
            this.tb_contador.Name = "tb_contador";
            this.tb_contador.ReadOnly = true;
            this.tb_contador.Size = new System.Drawing.Size(100, 20);
            this.tb_contador.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Contador:";
            // 
            // bt_agregar
            // 
            this.bt_agregar.Location = new System.Drawing.Point(26, 55);
            this.bt_agregar.Name = "bt_agregar";
            this.bt_agregar.Size = new System.Drawing.Size(75, 23);
            this.bt_agregar.TabIndex = 2;
            this.bt_agregar.Text = "Agregar";
            this.bt_agregar.UseVisualStyleBackColor = true;
            this.bt_agregar.Click += new System.EventHandler(this.bt_agregar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Promedio";
            // 
            // tb_promedio
            // 
            this.tb_promedio.Location = new System.Drawing.Point(12, 162);
            this.tb_promedio.Name = "tb_promedio";
            this.tb_promedio.ReadOnly = true;
            this.tb_promedio.Size = new System.Drawing.Size(100, 20);
            this.tb_promedio.TabIndex = 6;
            // 
            // ListaCalif
            // 
            this.ListaCalif.FormattingEnabled = true;
            this.ListaCalif.Location = new System.Drawing.Point(152, 15);
            this.ListaCalif.Name = "ListaCalif";
            this.ListaCalif.Size = new System.Drawing.Size(120, 186);
            this.ListaCalif.TabIndex = 7;
            // 
            // Frm_Promedio10Materias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(284, 226);
            this.Controls.Add(this.ListaCalif);
            this.Controls.Add(this.tb_promedio);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.bt_agregar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_contador);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_num);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Frm_Promedio10Materias";
            this.Text = "Promedio de 10 Materias";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_num;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_contador;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bt_agregar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_promedio;
        private System.Windows.Forms.ListBox ListaCalif;
    }
}