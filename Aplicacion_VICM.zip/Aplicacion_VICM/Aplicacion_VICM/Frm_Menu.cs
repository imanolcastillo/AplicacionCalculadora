﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicacion_VICM
{
    public partial class Frm_Menu : Form
    {
        public Frm_Menu()
        {
            InitializeComponent();
        }

        private void Min_OperacionesBasicas_Click(object sender, EventArgs e)
        {
            Frm_OperacionesBasicas chForm = new Frm_OperacionesBasicas();
            chForm.MdiParent = this;
            chForm.Show();
        }

        private void Min_Suma2Numeros_Click(object sender, EventArgs e)
        {
            Frm_Suma2Num chForm = new Frm_Suma2Num();
            chForm.MdiParent = this;
            chForm.Show();
        }

        private void Min_MayoryMenorNNumeros_Click(object sender, EventArgs e)
        {
            Frm_MayorMenorNNumeros chForm = new Frm_MayorMenorNNumeros();
            chForm.MdiParent = this;
            chForm.Show();
        }

        private void Min_SumatoriaPrimeros20Num_Click(object sender, EventArgs e)
        {
            Frm_SumatoriaPrimeros20Num chForm = new Frm_SumatoriaPrimeros20Num();
            chForm.MdiParent = this;
            chForm.Show();
        }

        private void Min_OrdenarNNumerosDescendente_Click(object sender, EventArgs e)
        {
            Frm_OrdernarNNumerosDescendente chForm = new Frm_OrdernarNNumerosDescendente();
            chForm.MdiParent = this;
            chForm.Show();
        }
   
        private void Min_Promedio10Materias_Click(object sender, EventArgs e)
        {
            Frm_Promedio10Materias chForm = new Frm_Promedio10Materias();
            chForm.MdiParent = this;
            chForm.Show();
        }

        private void Frm_Menu_Load(object sender, EventArgs e)
        {

        }
    }
}
