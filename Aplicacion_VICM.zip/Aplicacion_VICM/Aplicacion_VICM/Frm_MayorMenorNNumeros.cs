﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicacion_VICM
{
    public partial class Frm_MayorMenorNNumeros : Form
    {
        public Frm_MayorMenorNNumeros()
        {
            InitializeComponent();
            Bitmap img = new Bitmap(Application.StartupPath+"/img/Fondo4.jpg");
            this.BackgroundImage = img;
        }

        private void bt_agregarnums_Click(object sender, EventArgs e)
        {
            Numeros.Items.Add(tb_num.Text);
            if (mayor.Text == "")
            {
                mayor.Text = tb_num.Text;
                menor.Text = tb_num.Text;
            }
            else
            {
                if (Convert.ToDecimal(tb_num.Text) > Convert.ToDecimal(mayor.Text))
                {
                    mayor.Text = tb_num.Text;
                }
                if (Convert.ToDecimal(tb_num.Text) < Convert.ToDecimal(menor.Text))
                {
                    menor.Text = tb_num.Text;
                }
            }
            tb_num.Clear();
            tb_num.Focus();
        }
    }
}
