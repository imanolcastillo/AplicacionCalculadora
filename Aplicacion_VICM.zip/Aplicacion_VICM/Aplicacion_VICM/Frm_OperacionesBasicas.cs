﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicacion_VICM
{
    public partial class Frm_OperacionesBasicas : Form
    {
        public Frm_OperacionesBasicas()
        {
            InitializeComponent();
        }

        private void bt_suma_Click(object sender, EventArgs e)
        {
            lb_cantidad.Text = Convert.ToString(Convert.ToInt16(tb_num1.Text) + Convert.ToInt16(tb_num2.Text));
        }

        private void bt_resta_Click(object sender, EventArgs e)
        {
            lb_cantidad.Text = Convert.ToString(Convert.ToInt16(tb_num1.Text) - Convert.ToInt16(tb_num2.Text));
        }

        private void bt_multiplicacion_Click(object sender, EventArgs e)
        {
            lb_cantidad.Text = Convert.ToString(Convert.ToInt16(tb_num1.Text) * Convert.ToInt16(tb_num2.Text));
        }

        private void bt_division_Click(object sender, EventArgs e)
        {
            lb_cantidad.Text = Convert.ToString(Convert.ToInt16(tb_num1.Text) / Convert.ToInt16(tb_num2.Text));
        }
    }
}
