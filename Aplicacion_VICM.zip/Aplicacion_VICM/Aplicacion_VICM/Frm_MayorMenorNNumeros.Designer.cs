﻿namespace Aplicacion_VICM
{
    partial class Frm_MayorMenorNNumeros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_num = new System.Windows.Forms.TextBox();
            this.bt_agregarnums = new System.Windows.Forms.Button();
            this.Numeros = new System.Windows.Forms.ListBox();
            this.mayor = new System.Windows.Forms.TextBox();
            this.menor = new System.Windows.Forms.TextBox();
            this.lb_num = new System.Windows.Forms.Label();
            this.lb_mayor = new System.Windows.Forms.Label();
            this.lb_menor = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tb_num
            // 
            this.tb_num.Location = new System.Drawing.Point(25, 48);
            this.tb_num.Name = "tb_num";
            this.tb_num.Size = new System.Drawing.Size(100, 20);
            this.tb_num.TabIndex = 0;
            // 
            // bt_agregarnums
            // 
            this.bt_agregarnums.Location = new System.Drawing.Point(37, 84);
            this.bt_agregarnums.Name = "bt_agregarnums";
            this.bt_agregarnums.Size = new System.Drawing.Size(75, 39);
            this.bt_agregarnums.TabIndex = 1;
            this.bt_agregarnums.Text = "Agregar números";
            this.bt_agregarnums.UseVisualStyleBackColor = true;
            this.bt_agregarnums.Click += new System.EventHandler(this.bt_agregarnums_Click);
            // 
            // Numeros
            // 
            this.Numeros.AllowDrop = true;
            this.Numeros.BackColor = System.Drawing.Color.Gray;
            this.Numeros.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Numeros.FormattingEnabled = true;
            this.Numeros.Location = new System.Drawing.Point(152, 31);
            this.Numeros.Name = "Numeros";
            this.Numeros.Size = new System.Drawing.Size(120, 197);
            this.Numeros.TabIndex = 2;
            this.Numeros.Tag = "";
            // 
            // mayor
            // 
            this.mayor.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.mayor.Location = new System.Drawing.Point(25, 151);
            this.mayor.Name = "mayor";
            this.mayor.ReadOnly = true;
            this.mayor.Size = new System.Drawing.Size(100, 20);
            this.mayor.TabIndex = 3;
            this.mayor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // menor
            // 
            this.menor.Location = new System.Drawing.Point(25, 195);
            this.menor.Name = "menor";
            this.menor.ReadOnly = true;
            this.menor.Size = new System.Drawing.Size(100, 20);
            this.menor.TabIndex = 4;
            this.menor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lb_num
            // 
            this.lb_num.AutoSize = true;
            this.lb_num.Location = new System.Drawing.Point(25, 29);
            this.lb_num.Name = "lb_num";
            this.lb_num.Size = new System.Drawing.Size(47, 13);
            this.lb_num.TabIndex = 5;
            this.lb_num.Text = "Número:";
            // 
            // lb_mayor
            // 
            this.lb_mayor.AutoSize = true;
            this.lb_mayor.Location = new System.Drawing.Point(25, 135);
            this.lb_mayor.Name = "lb_mayor";
            this.lb_mayor.Size = new System.Drawing.Size(39, 13);
            this.lb_mayor.TabIndex = 6;
            this.lb_mayor.Text = "Mayor:";
            // 
            // lb_menor
            // 
            this.lb_menor.AutoSize = true;
            this.lb_menor.Location = new System.Drawing.Point(25, 179);
            this.lb_menor.Name = "lb_menor";
            this.lb_menor.Size = new System.Drawing.Size(40, 13);
            this.lb_menor.TabIndex = 7;
            this.lb_menor.Text = "Menor:";
            // 
            // Frm_MayorMenorNNumeros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.lb_menor);
            this.Controls.Add(this.lb_mayor);
            this.Controls.Add(this.lb_num);
            this.Controls.Add(this.menor);
            this.Controls.Add(this.mayor);
            this.Controls.Add(this.Numeros);
            this.Controls.Add(this.bt_agregarnums);
            this.Controls.Add(this.tb_num);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Frm_MayorMenorNNumeros";
            this.Text = "Mayor y Menor de \"N\" Numeros";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_num;
        private System.Windows.Forms.Button bt_agregarnums;
        private System.Windows.Forms.ListBox Numeros;
        private System.Windows.Forms.TextBox mayor;
        private System.Windows.Forms.TextBox menor;
        private System.Windows.Forms.Label lb_num;
        private System.Windows.Forms.Label lb_mayor;
        private System.Windows.Forms.Label lb_menor;
    }
}