﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicacion_VICM
{
    public partial class Frm_SumatoriaPrimeros20Num : Form
    {
        public Frm_SumatoriaPrimeros20Num()
        {
            InitializeComponent();
            Bitmap img = new Bitmap(Application.StartupPath + "/img/Fondo3.jpg");
            this.BackgroundImage = img;
        }

        Decimal suma = 0;
        int contador = 0;
        private void bt_agregar_Click(object sender, EventArgs e)
        {
            if (contador < 20)
            {
                ListaNum.Items.Add(tbnum.Text);
                Decimal num = Convert.ToDecimal(tbnum.Text);
                suma = suma + num;
                tbresultado.Text = Convert.ToString(suma);
                contador++;
                tbcontador.Text = Convert.ToString(contador);
            }
            tbnum.Clear();
            tbnum.Focus();
        }

        private void Frm_SumatoriaPrimeros20Num_Load(object sender, EventArgs e)
        {

        }
    }
}
