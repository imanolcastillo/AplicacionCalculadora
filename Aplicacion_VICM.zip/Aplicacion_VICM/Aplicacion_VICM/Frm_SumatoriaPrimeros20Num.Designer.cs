﻿namespace Aplicacion_VICM
{
    partial class Frm_SumatoriaPrimeros20Num
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_num = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_agregar = new System.Windows.Forms.Button();
            this.tb_resultado = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ListaNums = new System.Windows.Forms.ListBox();
            this.tb_contador = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbnum = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tbresultado = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ListaNum = new System.Windows.Forms.ListBox();
            this.tbcontador = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tb_num
            // 
            this.tb_num.Location = new System.Drawing.Point(38, 47);
            this.tb_num.Name = "tb_num";
            this.tb_num.Size = new System.Drawing.Size(100, 20);
            this.tb_num.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Número:";
            // 
            // bt_agregar
            // 
            this.bt_agregar.Location = new System.Drawing.Point(38, 85);
            this.bt_agregar.Name = "bt_agregar";
            this.bt_agregar.Size = new System.Drawing.Size(75, 23);
            this.bt_agregar.TabIndex = 2;
            this.bt_agregar.Text = "Agregar";
            this.bt_agregar.UseVisualStyleBackColor = true;
            this.bt_agregar.Click += new System.EventHandler(this.bt_agregar_Click);
            // 
            // tb_resultado
            // 
            this.tb_resultado.Location = new System.Drawing.Point(38, 199);
            this.tb_resultado.Name = "tb_resultado";
            this.tb_resultado.ReadOnly = true;
            this.tb_resultado.Size = new System.Drawing.Size(100, 20);
            this.tb_resultado.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 183);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Resultado:";
            // 
            // ListaNums
            // 
            this.ListaNums.FormattingEnabled = true;
            this.ListaNums.Location = new System.Drawing.Point(194, 18);
            this.ListaNums.Name = "ListaNums";
            this.ListaNums.Size = new System.Drawing.Size(120, 225);
            this.ListaNums.TabIndex = 5;
            // 
            // tb_contador
            // 
            this.tb_contador.Location = new System.Drawing.Point(38, 140);
            this.tb_contador.Name = "tb_contador";
            this.tb_contador.ReadOnly = true;
            this.tb_contador.Size = new System.Drawing.Size(100, 20);
            this.tb_contador.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Contador:";
            // 
            // tbnum
            // 
            this.tbnum.Location = new System.Drawing.Point(38, 47);
            this.tbnum.Name = "tbnum";
            this.tbnum.Size = new System.Drawing.Size(100, 20);
            this.tbnum.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Número:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(38, 85);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Agregar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.bt_agregar_Click);
            // 
            // tbresultado
            // 
            this.tbresultado.Location = new System.Drawing.Point(38, 199);
            this.tbresultado.Name = "tbresultado";
            this.tbresultado.ReadOnly = true;
            this.tbresultado.Size = new System.Drawing.Size(100, 20);
            this.tbresultado.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 183);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Resultado:";
            // 
            // ListaNum
            // 
            this.ListaNum.FormattingEnabled = true;
            this.ListaNum.Location = new System.Drawing.Point(194, 18);
            this.ListaNum.Name = "ListaNum";
            this.ListaNum.Size = new System.Drawing.Size(120, 225);
            this.ListaNum.TabIndex = 5;
            // 
            // tbcontador
            // 
            this.tbcontador.Location = new System.Drawing.Point(38, 140);
            this.tbcontador.Name = "tbcontador";
            this.tbcontador.ReadOnly = true;
            this.tbcontador.Size = new System.Drawing.Size(100, 20);
            this.tbcontador.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(38, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Contador:";
            // 
            // Frm_SumatoriaPrimeros20Num
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 261);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbcontador);
            this.Controls.Add(this.tb_contador);
            this.Controls.Add(this.ListaNum);
            this.Controls.Add(this.ListaNums);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbresultado);
            this.Controls.Add(this.tb_resultado);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bt_agregar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbnum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_num);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Frm_SumatoriaPrimeros20Num";
            this.Text = "Frm_SumatoriaPrimeros20Num";
            this.Load += new System.EventHandler(this.Frm_SumatoriaPrimeros20Num_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_num;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_agregar;
        private System.Windows.Forms.TextBox tb_resultado;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox ListaNums;
        private System.Windows.Forms.TextBox tb_contador;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbnum;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbresultado;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox ListaNum;
        private System.Windows.Forms.TextBox tbcontador;
        private System.Windows.Forms.Label label6;
    }
}