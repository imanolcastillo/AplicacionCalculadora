﻿namespace Aplicacion_VICM
{
    partial class Frm_Suma2Num
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_num1 = new System.Windows.Forms.TextBox();
            this.tb_num2 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lb_num2 = new System.Windows.Forms.Label();
            this.lb_num1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bt_salir = new System.Windows.Forms.Button();
            this.bt_suma = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lb_resultado = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_num1
            // 
            this.tb_num1.Location = new System.Drawing.Point(39, 22);
            this.tb_num1.Name = "tb_num1";
            this.tb_num1.Size = new System.Drawing.Size(100, 20);
            this.tb_num1.TabIndex = 0;
            // 
            // tb_num2
            // 
            this.tb_num2.Location = new System.Drawing.Point(39, 60);
            this.tb_num2.Name = "tb_num2";
            this.tb_num2.Size = new System.Drawing.Size(100, 20);
            this.tb_num2.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.lb_num2);
            this.panel1.Controls.Add(this.lb_num1);
            this.panel1.Controls.Add(this.tb_num1);
            this.panel1.Controls.Add(this.tb_num2);
            this.panel1.Location = new System.Drawing.Point(12, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(178, 100);
            this.panel1.TabIndex = 2;
            // 
            // lb_num2
            // 
            this.lb_num2.AutoSize = true;
            this.lb_num2.Location = new System.Drawing.Point(36, 45);
            this.lb_num2.Name = "lb_num2";
            this.lb_num2.Size = new System.Drawing.Size(56, 13);
            this.lb_num2.TabIndex = 3;
            this.lb_num2.Text = "Número 2:";
            // 
            // lb_num1
            // 
            this.lb_num1.AutoSize = true;
            this.lb_num1.Location = new System.Drawing.Point(39, 4);
            this.lb_num1.Name = "lb_num1";
            this.lb_num1.Size = new System.Drawing.Size(56, 13);
            this.lb_num1.TabIndex = 2;
            this.lb_num1.Text = "Número 1:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel2.Controls.Add(this.bt_salir);
            this.panel2.Controls.Add(this.bt_suma);
            this.panel2.Location = new System.Drawing.Point(205, 21);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(102, 100);
            this.panel2.TabIndex = 3;
            // 
            // bt_salir
            // 
            this.bt_salir.Location = new System.Drawing.Point(13, 58);
            this.bt_salir.Name = "bt_salir";
            this.bt_salir.Size = new System.Drawing.Size(75, 23);
            this.bt_salir.TabIndex = 1;
            this.bt_salir.Text = "Salir";
            this.bt_salir.UseVisualStyleBackColor = true;
            this.bt_salir.Click += new System.EventHandler(this.bt_salir_Click);
            // 
            // bt_suma
            // 
            this.bt_suma.Location = new System.Drawing.Point(13, 19);
            this.bt_suma.Name = "bt_suma";
            this.bt_suma.Size = new System.Drawing.Size(75, 23);
            this.bt_suma.TabIndex = 0;
            this.bt_suma.Text = "Suma";
            this.bt_suma.UseVisualStyleBackColor = true;
            this.bt_suma.Click += new System.EventHandler(this.bt_suma_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel3.Controls.Add(this.lb_resultado);
            this.panel3.Location = new System.Drawing.Point(13, 139);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(177, 35);
            this.panel3.TabIndex = 4;
            // 
            // lb_resultado
            // 
            this.lb_resultado.AutoSize = true;
            this.lb_resultado.Location = new System.Drawing.Point(3, 12);
            this.lb_resultado.Name = "lb_resultado";
            this.lb_resultado.Size = new System.Drawing.Size(154, 13);
            this.lb_resultado.TabIndex = 0;
            this.lb_resultado.Text = "Aqui encontraras tu resultado :)";
            // 
            // Frm_Suma2Num
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(320, 187);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Frm_Suma2Num";
            this.Text = "Frm_Suma2Num";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_num1;
        private System.Windows.Forms.TextBox tb_num2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lb_num2;
        private System.Windows.Forms.Label lb_num1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bt_salir;
        private System.Windows.Forms.Button bt_suma;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lb_resultado;
    }
}