﻿namespace Aplicacion_VICM
{
    partial class Frm_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.pRINCIPALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Min_OperacionesBasicas = new System.Windows.Forms.ToolStripMenuItem();
            this.Min_Suma2Numeros = new System.Windows.Forms.ToolStripMenuItem();
            this.Min_MayoryMenorNNumeros = new System.Windows.Forms.ToolStripMenuItem();
            this.Min_SumatoriaPrimeros20Num = new System.Windows.Forms.ToolStripMenuItem();
            this.Min_OrdenarNNumerosDescendente = new System.Windows.Forms.ToolStripMenuItem();
            this.Min_Promedio10Materias = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pRINCIPALToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(825, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // pRINCIPALToolStripMenuItem
            // 
            this.pRINCIPALToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Min_OperacionesBasicas,
            this.Min_Suma2Numeros,
            this.Min_MayoryMenorNNumeros,
            this.Min_SumatoriaPrimeros20Num,
            this.Min_OrdenarNNumerosDescendente,
            this.Min_Promedio10Materias});
            this.pRINCIPALToolStripMenuItem.Name = "pRINCIPALToolStripMenuItem";
            this.pRINCIPALToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.pRINCIPALToolStripMenuItem.Text = "PRINCIPAL";
            // 
            // Min_OperacionesBasicas
            // 
            this.Min_OperacionesBasicas.Name = "Min_OperacionesBasicas";
            this.Min_OperacionesBasicas.Size = new System.Drawing.Size(290, 22);
            this.Min_OperacionesBasicas.Text = "Operaciones Básicas";
            this.Min_OperacionesBasicas.Click += new System.EventHandler(this.Min_OperacionesBasicas_Click);
            // 
            // Min_Suma2Numeros
            // 
            this.Min_Suma2Numeros.Name = "Min_Suma2Numeros";
            this.Min_Suma2Numeros.Size = new System.Drawing.Size(290, 22);
            this.Min_Suma2Numeros.Text = "Suma 2 Números";
            this.Min_Suma2Numeros.Click += new System.EventHandler(this.Min_Suma2Numeros_Click);
            // 
            // Min_MayoryMenorNNumeros
            // 
            this.Min_MayoryMenorNNumeros.Name = "Min_MayoryMenorNNumeros";
            this.Min_MayoryMenorNNumeros.Size = new System.Drawing.Size(290, 22);
            this.Min_MayoryMenorNNumeros.Text = "Mayor y Menor \"N\" números";
            this.Min_MayoryMenorNNumeros.Click += new System.EventHandler(this.Min_MayoryMenorNNumeros_Click);
            // 
            // Min_SumatoriaPrimeros20Num
            // 
            this.Min_SumatoriaPrimeros20Num.Name = "Min_SumatoriaPrimeros20Num";
            this.Min_SumatoriaPrimeros20Num.Size = new System.Drawing.Size(290, 22);
            this.Min_SumatoriaPrimeros20Num.Text = "Sumatoria de los primeros 20 números";
            this.Min_SumatoriaPrimeros20Num.Click += new System.EventHandler(this.Min_SumatoriaPrimeros20Num_Click);
            // 
            // Min_OrdenarNNumerosDescendente
            // 
            this.Min_OrdenarNNumerosDescendente.Name = "Min_OrdenarNNumerosDescendente";
            this.Min_OrdenarNNumerosDescendente.Size = new System.Drawing.Size(290, 22);
            this.Min_OrdenarNNumerosDescendente.Text = "Ordenar \"N\" números de forma descente";
            this.Min_OrdenarNNumerosDescendente.Click += new System.EventHandler(this.Min_OrdenarNNumerosDescendente_Click);
            // 
            // Min_Promedio10Materias
            // 
            this.Min_Promedio10Materias.Name = "Min_Promedio10Materias";
            this.Min_Promedio10Materias.Size = new System.Drawing.Size(290, 22);
            this.Min_Promedio10Materias.Text = "Calcular promedio de tus 10 materias";
            this.Min_Promedio10Materias.Click += new System.EventHandler(this.Min_Promedio10Materias_Click);
            // 
            // Frm_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 532);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm_Menu";
            this.Text = "Menú";
            this.Load += new System.EventHandler(this.Frm_Menu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem pRINCIPALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Min_OperacionesBasicas;
        private System.Windows.Forms.ToolStripMenuItem Min_Suma2Numeros;
        private System.Windows.Forms.ToolStripMenuItem Min_MayoryMenorNNumeros;
        private System.Windows.Forms.ToolStripMenuItem Min_SumatoriaPrimeros20Num;
        private System.Windows.Forms.ToolStripMenuItem Min_OrdenarNNumerosDescendente;
        private System.Windows.Forms.ToolStripMenuItem Min_Promedio10Materias;
    }
}