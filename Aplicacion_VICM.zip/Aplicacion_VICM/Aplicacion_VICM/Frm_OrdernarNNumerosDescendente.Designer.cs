﻿namespace Aplicacion_VICM
{
    partial class Frm_OrdernarNNumerosDescendente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_num = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_agregar = new System.Windows.Forms.Button();
            this.ListaNums = new System.Windows.Forms.ListBox();
            this.Lista_Ordenar = new System.Windows.Forms.ListBox();
            this.bt_ordenar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_num
            // 
            this.tb_num.Location = new System.Drawing.Point(13, 45);
            this.tb_num.Name = "tb_num";
            this.tb_num.Size = new System.Drawing.Size(100, 20);
            this.tb_num.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Número:";
            // 
            // bt_agregar
            // 
            this.bt_agregar.Location = new System.Drawing.Point(26, 71);
            this.bt_agregar.Name = "bt_agregar";
            this.bt_agregar.Size = new System.Drawing.Size(75, 23);
            this.bt_agregar.TabIndex = 2;
            this.bt_agregar.Text = "Agregar";
            this.bt_agregar.UseVisualStyleBackColor = true;
            this.bt_agregar.Click += new System.EventHandler(this.Bt_agregar_Click);
            // 
            // ListaNums
            // 
            this.ListaNums.FormattingEnabled = true;
            this.ListaNums.Location = new System.Drawing.Point(143, 12);
            this.ListaNums.Name = "ListaNums";
            this.ListaNums.Size = new System.Drawing.Size(120, 238);
            this.ListaNums.TabIndex = 3;
            // 
            // Lista_Ordenar
            // 
            this.Lista_Ordenar.FormattingEnabled = true;
            this.Lista_Ordenar.Location = new System.Drawing.Point(282, 12);
            this.Lista_Ordenar.Name = "Lista_Ordenar";
            this.Lista_Ordenar.Size = new System.Drawing.Size(120, 238);
            this.Lista_Ordenar.TabIndex = 4;
            // 
            // bt_ordenar
            // 
            this.bt_ordenar.Location = new System.Drawing.Point(26, 158);
            this.bt_ordenar.Name = "bt_ordenar";
            this.bt_ordenar.Size = new System.Drawing.Size(75, 23);
            this.bt_ordenar.TabIndex = 5;
            this.bt_ordenar.Text = "Ordenar";
            this.bt_ordenar.UseVisualStyleBackColor = true;
            this.bt_ordenar.Click += new System.EventHandler(this.Bt_ordenar_Click);
            // 
            // Frm_OrdernarNNumerosDescendente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 261);
            this.Controls.Add(this.bt_ordenar);
            this.Controls.Add(this.Lista_Ordenar);
            this.Controls.Add(this.ListaNums);
            this.Controls.Add(this.bt_agregar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_num);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Frm_OrdernarNNumerosDescendente";
            this.Text = "Números descendente";
            this.Load += new System.EventHandler(this.Frm_OrdernarNNumerosDescendente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_num;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_agregar;
        private System.Windows.Forms.ListBox ListaNums;
        private System.Windows.Forms.ListBox Lista_Ordenar;
        private System.Windows.Forms.Button bt_ordenar;
    }
}