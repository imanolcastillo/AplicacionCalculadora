﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicacion_VICM
{
    public partial class Frm_Promedio10Materias : Form
    {
        public Frm_Promedio10Materias()
        {
            InitializeComponent();
            Bitmap img = new Bitmap(Application.StartupPath + "/img/Fondo1.jpg");
            this.BackgroundImage = img;
        }

        Decimal suma = 0;
        int contador = 0;
        private void bt_agregar_Click(object sender, EventArgs e)
        {
            {
                if (contador < 10)
                {
                    ListaCalif.Items.Add(tb_num.Text);
                    Decimal num = Convert.ToDecimal(tb_num.Text);
                    suma = suma + num / 10;
                    tb_promedio.Text = Convert.ToString(suma);
                    contador++;
                    tb_contador.Text = Convert.ToString(contador);
                }
                tb_num.Clear();
                tb_num.Focus();
            }
        }
    }
}
